package a4;

public class MinHeap implements Heap {
  
  private int size = 0; // number of elements currently in the heap
  private int[] elts;   // heap array
  private int max;      // array declared size
  
  // ================================================
  // constructors
  // ================================================
  
  public MinHeap(int umax) { // user defined heap size
    this.max = umax;
    this.elts = new int[umax];
  }
  public MinHeap( ) { // default heap size is 100
    this.max = 100;
    this.elts = new int[100];
  }

  //==================================================
  // methods we need to grade
  //==================================================
  
  public int[] getArray() { // do not change this method
    return this.elts;
  }
  
  //=========================================================
  // public methods -- Implement these for the assignment.
  // Note that we want a Min Heap... so the operations
  // getFront and delFront and insert have to compare 
  // for min being at the root  
  //========================================================= 


  public void insert(int p){
    //Hint: remember to update size.  Also, remember that we skip index 0 in the array.
    /*Your code here */
    if (this.size == this.max){
      return;
    }
    if (this.size == 0) {
      this.elts[1] = p;
      this.size++;
    } else {
      int prevIndex = this.size + 1;
      this.elts[prevIndex] = p;
      int floorIndex = (int) Math.floor((this.size + 1)/2);
      while (p < this.elts[floorIndex]) {
        int temp = this.elts[floorIndex];
        this.elts[floorIndex] = p;
        this.elts[prevIndex] = temp;
        prevIndex = floorIndex;
        floorIndex = (int) Math.floor(floorIndex/2);
      }
      this.size++;

    }

  }
  
  public void delFront(){
    /*Your code here */
    if (this.size() == 0){
      return;
    }
    else {
      this.elts[1] = this.elts[this.size];
      this.elts[this.size] = this.elts[this.size - 1];
      this.size--;
      int parentIndex = 1;
      int childIndex;
      int parentElm = this.elts[parentIndex];
      while(hasLeftChild(parentIndex)){
        childIndex = parentIndex * 2;
        if (hasRightChild(parentIndex) && this.elts[childIndex] > this.elts[childIndex + 1]){
          childIndex = parentIndex * 2 + 1;
        }
        if (this.elts[parentIndex] > this.elts[childIndex]){
          this.elts[parentIndex] = this.elts[childIndex];
          this.elts[childIndex] = parentElm;
          parentIndex = childIndex;
          parentElm = this.elts[parentIndex];
        } else{
          return;
        }

      }

    }
  }
  private boolean hasRightChild(int z){
    if (z * 2 + 1 > this.size){
      return false;
    }
    return true;
  }
  private boolean hasLeftChild(int z){
  if (z * 2 > this.size){
    return false;
  }
  return true;
  }
  
  public int getFront() throws IllegalStateException {
    //Return the element at the front (i.e., the smallest) element in the min-heap.
    //If the min-heap has no elements, throw an IllegalStateException.
    /*Your code here */
    if (this.size() == 0) {
      throw new IllegalStateException(); //Dummy return statement.  Remove (or move elsewhere) when you implement!
    } else return this.elts[1];
  }
  
  public boolean empty() {
    /*Your code here */
    if (this.size() == 0){
      return true;
    }
    else return false;
      //Dummy return statement.  Remove (or move elsewhere) when you implement!
    }


  public int size() {
    /*Your code here */
    return this.size; //Dummy return statement.  Remove (or move elsewhere) when you implement!
  }
  
  public void clear() { 
    /*Your code here */
    int maxSize = this.size();
  for (int i = 0; i< maxSize; i++){
    this.delFront();
  }
  }
  
  public void build (int[] e, int ne) {
    //Hint: remember to skip slot 0 in the heap array.
    /* Your code here */
    if (ne > this.max){
      return;
    }
    this.clear();
    this.size = ne;
    int x = 0;
    while (x < this.size){
      this.elts[x+1] = e[x];
      x++;
    }
    while (ne >= 1){
      int idx = this.elts[ne];
      int child = ne;
      int parent = ne /2;
      while (child > 1 && idx < this.elts[parent]){
        int temp = this.elts[child];
        this.elts[child] = this.elts[parent];
        this.elts[parent] = temp;
        child = parent;
        parent = child /2;
      }
      this.elts[child] = idx;
      ne = ne -1;
    }

    }
  
  public int[] sort() {
    // Hint: the smallest element will go in slot 0
    /*Your code here */
    int new_array[] = new int[this.size];
    for (int i = 0; i < this.size; i++) {
      new_array[i] = elts[i + 1];
    }
    for (int i = 0; i<new_array.length-1; i++){
      for (int j = i + 1; j<new_array.length; j++){
        if (new_array[i] > new_array[j]){
          int temporary = new_array[i];
          new_array[i] = new_array[j];
          new_array[j] = temporary;
        }
      }
    }
    return new_array;// Dummy return statement.  Remove (or move elsewhere) when you implement!
  }

}
