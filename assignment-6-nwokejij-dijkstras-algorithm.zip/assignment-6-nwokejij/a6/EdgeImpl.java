package a6;

public class EdgeImpl implements Edge {
    /* You will include the implementations for any edge methods you need in this file. */

    /*Hint: Make sure you update the Edge interface in Edge.java when you add a new method implementation
    in EdgeImpl.java, and vice-versa.  getName() in Node.java and NodeImpl.java is an example.  Also, files in
    previous homeworks (e.g., BST.java and BSTImpl.java in homework 3) are good examples of
    interfaces and their implementations.
     */
    private Node source;
    private int size = 0;
    private Node end;
    private double weight;
    /*Also, any edge fields you want to add for the object should go in this file.  */
    public EdgeImpl(){
        this.source = null;
        this.end = null;
    }
    public EdgeImpl(Node src, Node end){
        this.source = src;
        this.end = end;
        this.size++;
    }
    public String getSourceName(){
        return source.getName();
    }
    public String getEndName(){
        return end.getName();
    }
    public void nullNode(){
        this.source = null;
        this.end = null;
    }
    public void setWeight(Double d){
        this.weight = d;
    }
    public Double getWeight(){
        return this.weight;
    }

}
