package a6;

public class ShortestPathQueueObject {
    public String label;
    public double distance;

    public ShortestPathQueueObject(String label, double distance) {
        this.label = label;
        this.distance = distance;
    }

    public String returnLabel(){
        return this.label;
    }

    public Double returnDistance(){
        return this.distance;
    }
}
