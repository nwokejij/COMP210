package a6;

public class Main {


    public static void main(String[] args) {

        //You are encouraged (but not required) to include your testing code here.

        //Hint: Try to test basic operations (e.g., adding a few nodes and edges to graphs)
        //before you implement more complex methods
        Graph g = new GraphImpl();


        g.addNode("A");
        g.addNode("B");
        g.addNode("C");
        g.addNode("F");
        System.out.println(g.numNodes());
        System.out.println(g.addEdge("A", "B", 1.0));
        System.out.println(g.addEdge("A", "C", 2.0));
        System.out.println(g.addEdge("C", "B", 2.0));
        System.out.println(g.numEdges());
        System.out.println(g.deleteNode("C"));
        System.out.println(g.deleteEdge("A", "B"));
        System.out.println(g.deleteEdge("B", "A"));

        System.out.println(g.dijkstra("B"));





    }

}
