package a6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class NodeImpl implements Node {

    /* You will include the method signatures (return type, name, and arg types) for any node methods you
    need in this file. */

    /*Hint: Make sure you update the Node interface in Node.java when you add a new method implementation
    in NodeImpl.java, and vice-versa.  getName() in Node.java and NodeImpl.java is an example.  Also, files in
    previous homeworks (e.g., BST.java and BSTImpl.java in homework 3) are good examples of
    interfaces and their implementations.
     */

    /*Also, any node fields you want to add for the object should go in this file.  */
    private String name;
    private int prereqs = 0;
    private ArrayList<Edge> connect = new ArrayList<>();
    private ArrayList<Node> isAffected = new ArrayList<>();
    private double sDistance = Double.MAX_VALUE;
    private Node prevNode;
    private boolean visited = false;


    public NodeImpl(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return this.name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<Edge> connect(){
        return this.connect;
    }
    public void connectNode(Node n) {
        Edge c = new EdgeImpl(this, n);
        connect.add(c);
        n.connect().add(c);
        this.affectNode(n);
        n.incPrereq();
    }

    public void endConnect(Node n) {
        Edge c = new EdgeImpl(n, this);
        connect.add(c);
        n.connect().add(c);
        this.incPrereq();
    }

    public boolean isNoided(Node n) {
        if (n == null){
            return false;
        } else if (n.getName() == this.getName()){
            return false;
        }
        for (Edge edg : n.connect() ) {
            if ((edg.getSourceName() == this.getName()) || (edg.getEndName() == this.getName())) {
                return true;
            }
        }
        return false;
    }

    public boolean deleteEdge(Node n) {
        if (isNoided(n) == false) {
            return false;
        } else {
            Edge tempEdge = null;
            for (Edge edg : n.connect() ){
                if ((edg.getSourceName() == this.getName() && edg.getEndName() == n.getName())){//|| ((edg.getEndName() == this.getName()) && (edg.getSourceName() == n.getName()))){

                    tempEdge = edg; // stores the edge so I can remove from List<Edge> of Node n (n.connect())
                    n.decPrereq();
                    this.connect().remove(edg);
                    this.affectedNodes().remove(n);
                }
            }
            if (tempEdge != null) {
                n.connect().remove(tempEdge);
            }
            tempEdge.nullNode();
        }
        return true;
    }
    public void incPrereq(){
        this.prereqs++;
    }
    public void decPrereq(){
        this.prereqs--;
    }
    public int getPrereq(){
        return this.prereqs;
    }
    public void affectNode(Node n){
        isAffected.add(n);
    }
    public ArrayList<Node> affectedNodes(){
        return this.isAffected;
    }

    public double getDistance(){
        return this.sDistance;
    }
    public void setDistance(double d) {this.sDistance = d;}
    public Node getPrevNode(){
        return this.prevNode;
    }
    public void setPrevNode(Node n){
        this.prevNode = n;
    }

    public boolean isSource(Node dest){
        if (this.isNoided(dest)) {
            for (Edge e: dest.connect()){
                if (e.getSourceName() == this.getName()){
                    return true;
                }
            }
        }
        return false;
    }
    public boolean isVisited(Node n){
        return visited;
    }

    public boolean hasAffectedNodes(){
        if (this.affectedNodes().isEmpty()){
            return false;
        } else return true;
    }
    public Edge returnSharedEdge(Node n){
        if (this.isNoided(n)){
            for (Edge e: this.connect()){
                if ((e.getSourceName() == n.getName()) || (e.getEndName() == n.getName())){
                    if (e.getSourceName() == n.getName()){
                        return e;
                    } else if (e.getEndName() == n.getName()){
                        return e;
                    }
                }
            }
        }
        return null;
    }
    
}
