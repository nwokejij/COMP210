package a6;
import java.util.ArrayList;
import java.util.List;


public interface Node {

     /* You will include the method signatures (return type, name, and arg types) for any node methods you
    need in this file. */

    /*Hint: Make sure you update the Node interface in Node.java when you add a new method implementation
    in NodeImpl.java, and vice-versa.  getName() in Node.java and NodeImpl.java is an example.  Also, files in
    previous homeworks (e.g., BST.java and BSTImpl.java in homework 3) are good examples of
    interfaces and their implementations.
     */

     /**
      * @return the name of the node
      */
     String getName();
     void setName(String name);
     boolean isNoided(Node n);
     boolean deleteEdge(Node n);
     void connectNode(Node n);
     void endConnect(Node n);
     void incPrereq();
     void decPrereq();
     int getPrereq();

     void affectNode(Node n);

     ArrayList<Node> affectedNodes();


     ArrayList<Edge> connect();
     double getDistance();
     void setDistance(double d);

     void setPrevNode(Node n);
     Node getPrevNode();

     boolean isSource(Node dest);
     boolean isVisited(Node n);
     boolean hasAffectedNodes();
     Edge returnSharedEdge(Node n);

}