
package a6;

import java.util.*;

public class GraphImpl implements Graph {
    Map<String, Node> nodes; //Do not delete.  Use this field to store your nodes.
    // key: name of node. value: a5.Node object associated with name
    private int numOfEdges = 0;


    public GraphImpl() {
        nodes = new HashMap<>();
    }


    @Override
    public boolean addNode(String name) {
        if ((nodes.containsKey(name)) || (name == null)) {
            return false;
        }
        Node c = new NodeImpl(name);
        nodes.put(name, c);
        return true;
    }

    @Override
    public boolean addEdge(String src, String dest, double weight) {
        if (weight < 0) {
            return false;
        } else if ((nodes.containsKey(src) == false) || (nodes.containsKey(dest) == false)){
            return false;
        } else if (src == dest){
            return false;
        }
        for (Edge e: nodes.get(src).connect()){
            if (e.getEndName() == dest){
                return false;
            }
        }
        nodes.get(src).connectNode(nodes.get(dest));
        nodes.get(src).returnSharedEdge(nodes.get(dest)).setWeight(weight);
        this.numOfEdges++;
        return true;

    }

    @Override
    public boolean deleteNode(String name) {
        //Hint: Do you need to remove edges when you delete a node?
        //Hint: Do you need to remove edges when you delete a node?
        if (nodes.containsKey(name)) {
            /*for (Node n : nodes.get(name).affectedNodes()) {
                nodes.get(name).deleteEdge(n);
                numOfEdges--;
            }
//anything
            */

            for (String key : nodes.keySet()) {
                if (nodes.get(key).getName() != nodes.get(name).getName()) {
                    if (nodes.get(key).isNoided(nodes.get(name))) { //two nodes share an edge (could be source or end)
                        nodes.get(key).deleteEdge(nodes.get(name));
                        numOfEdges--;
                    }
                }
            }

            nodes.remove(name);
            return true;
        }

        return false;

    }


    @Override
    public boolean deleteEdge(String src, String dest) {
        boolean isThere = false;
        if ((nodes.containsKey(src) && nodes.containsKey(dest)) && (nodes.get(src).isNoided(nodes.get(dest)))){
            for (Edge e: nodes.get(src).connect()){
                if ((e.getSourceName() == nodes.get(src).getName()) && (e.getEndName() == nodes.get(dest).getName())){
                    isThere = true;
                }
            }
            if (isThere == false){
                return false;
            }
            nodes.get(src).deleteEdge(nodes.get(dest));
            numOfEdges--;
            return true;
        }
        return false;

    }

    @Override
    public int numNodes() {
        return nodes.size();
    }

    @Override
    public int numEdges() {
        return numOfEdges;
    }

    @Override
    public Map<String, Double> dijkstra(String start) {
        if (!nodes.containsKey(start)) {
            return null;
        }
        Map<String, Double> unvisited = new HashMap<>();
        Map<String, Double> visited = new HashMap<>();
        boolean isNoided = false;
        for (String s: nodes.keySet()){
            if (nodes.get(start).isNoided(nodes.get(s))){
                isNoided = true;
            }
        }

        if (isNoided == false){
            visited.put(start, 0.0);
            return visited;//source + 0.0
        }
        Comparator<ShortestPathQueueObject> compare = (a, b) -> Double.compare(a.distance, b.distance);
        PriorityQueue<ShortestPathQueueObject> queue = new PriorityQueue<ShortestPathQueueObject>(compare);
        nodes.get(start).setDistance(0.0);
        queue.add(new ShortestPathQueueObject(start, 0.0));
        for (String s : nodes.keySet()) {
            unvisited.put(s, nodes.get(s).getDistance());
        }
        while (!queue.isEmpty()){
            Node tempNode = nodes.get(queue.peek().returnLabel());
            Double tempDist = queue.peek().returnDistance();
            if (tempNode.hasAffectedNodes()) {
                for (Node n : tempNode.affectedNodes()) {
                    if (tempDist + tempNode.returnSharedEdge(n).getWeight() < n.getDistance()) {
                        n.setDistance(tempNode.returnSharedEdge(n).getWeight());
                        unvisited.replace(n.getName(), n.getDistance());
                        queue.add(new ShortestPathQueueObject(n.getName(), n.getDistance()));
                    }

                }
            }
            visited.put(tempNode.getName(), tempNode.getDistance());
            queue.poll();
        }




//        if (s != start) {
//            if (nodes.get(start).isNoided(nodes.get(s))) {
//                unvisited.put(s, nodes.get(s).returnWeight(nodes.get(s)));
//                if (nodes.get(s).returnWeight(nodes.get(s)) < smallestValue) {
//                    smallestValue = nodes.get(s).returnWeight(nodes.get(s));
//                    tempNode = nodes.get(s);
//                }
//
//            } else unvisited.put(s, nodes.get(s).getDistance());
//        }




//        if (unvisited == null){
//            visited.put(start, 0.0);
//            return visited;
//        }
//        while (!unvisited.isEmpty()) {
//            for (String key : unvisited.keySet()) {
//                if (tempNode.isSource(nodes.get(key))) { //could replace with affectedNodes
//                    if (tempDist + tempNode.returnWeight(nodes.get(key)) < unvisited.get(key)) {
//                        unvisited.replace(key, tempDist + tempNode.returnWeight(nodes.get(key)));
////                        if (nodes.get(tempNode).returnWeight(nodes.get(key)) < smallestValue) {
////                            smallestValue = nodes.get(tempNode).returnWeight(nodes.get(key)); //what's gonna happen once the node is deleted from unvisited
////                            otherTempNode = nodes.get(key);
////                        }
//                    }
//                }
//            }
//            for (String a: unvisited.keySet()) {
//                if (nodes.get(a) != tempNode){
//                    if (unvisited.get(a) < smallestValue) {
//                        smallestValue = unvisited.get(a);
//                        otherTempNode = nodes.get(a);
//                    }
//            }
//                visited.put(tempNode.getName(), tempDist);
//                unvisited.remove(tempNode.getName());
//                if (unvisited.isEmpty()) {
//                    tempNode = null;
//                } else {
//                    tempNode = otherTempNode;
//                    tempDist = smallestValue;
//                    smallestValue = Double.MAX_VALUE;
//                }
//
//            }
//
//        }


        return visited;  //Dummy return value.  Remove when you implement!
    }
}