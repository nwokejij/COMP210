package assn2;

public class Main {
   public static void main (String[] args) {
      List lst = new ArrayList(100);
      
      /*Sample code is provided below for you to examine for testing purposes. */
      //List lst = new LinkedList();

      Tester tst = new Tester();

      //tst.set(lst);
      //tst.findLast(lst);
      //tst.inSort(lst);
       tst.bubbleIns(lst);
  }
}
